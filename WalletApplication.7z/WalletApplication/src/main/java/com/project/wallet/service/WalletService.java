package com.project.wallet.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.stream.Stream;

import com.project.wallet.bean.Account;
import com.project.wallet.dao.IWalletDao;
import com.project.wallet.dao.WalletDao;
import com.project.wallet.exception.WalletException;

public class WalletService implements IWalletService {
	Account temp = new Account();
	IWalletDao dao;
	 public WalletService() {
		 dao = new WalletDao();
		 
	}
	 LocalDate tDate = LocalDate.now();
	 static String namePattern = "[A-Z]{1}[a-z]{2,}";
	 static String numberPattern = "(\\d){10}";
	 static String passwordPattern = "((?=.*\\d)(?=.*[a-z])(?=.*[@#$%]).{6,15})";
	
	 public  boolean validateCustName(String name)
	 {	if(name.matches(namePattern))
	 		return true;
	 	else
	 		return false;
	 }
	 
	 
	 public  boolean validateCustPhoneNumber(String number) {
			if(number.matches(numberPattern))
				return true;
			else
				return false;
		}
	 
	 
	 public boolean validateCustAge(int age) {
		if(age<=110&&age>=1)
			return true;
		else
			return false;
	
	 }
	
	 public  boolean validateCustPwd(String pwd) {
		 if(pwd.matches(passwordPattern))
			 return true;
		 else
			 return false;
	 }
	
	 public  boolean validateAmt(double amt) {
		 if(amt>0.00)
			 return true;
		 else
			 return false;
	 }
	 @Override
	 public double depositDao(double money) {
		 temp.setCustomerBalance(temp.getCustomerBalance()+money);
		 temp.settDetails("Date :"+tDate+" Depsoited Amount :"+money+" Total Balance :"+temp.getCustomerBalance());
		 dao.updateDetails(temp.getAccountNum(),temp);
		 return temp.getCustomerBalance();
	}
	 @Override
	 public double withdrawDao(double money) {
		 if(money<temp.getCustomerBalance()) {
			 temp.setCustomerBalance(temp.getCustomerBalance()-money);
			 temp.settDetails("Date :"+tDate+" Amount Withdrawn :"+money+" Total Balance :"+temp.getCustomerBalance());
			 dao.updateDetails(temp.getAccountNum(),temp);
		 } else
			System.out.println(" Low Balance :( ");
		return temp.getCustomerBalance();
}


@Override
public boolean checkLogin(int accNo) throws WalletException {
	temp =dao.loginUser(accNo);
	if(temp!=null)
	return true;
	else 
		return false;
}

@Override
public boolean checkPassword(String pwd) {
	if(temp.getCustomerPassword().matches(pwd))
		return true;
	else
		return false;
}
@Override
public String currentUser() {
	return temp.getCustomerName();
}


@Override
public int addAccountDao(Account account) {
	// TODO Auto-generated method stub
	return dao.accountCreation(account);
}


@Override
public double showBalanceDao() {
	// TODO Auto-generated method stub
	return temp.getCustomerBalance();
}


@Override
public boolean transferAmount(int toAccountNumber, double money)
		throws WalletException {
	// TODO Auto-generated method stub
	Account ftTemp =new Account();
	if(temp.getCustomerBalance()>=money) {
		ftTemp = dao.loginUser(toAccountNumber);
		if(ftTemp!=null) {
			ftTemp.setCustomerBalance(ftTemp.getCustomerBalance()+money);
			temp.setCustomerBalance(temp.getCustomerBalance()-money);
			temp.settDetails("Date :"+tDate+" Amount Transfered :"+money+" To Acc No: "+ftTemp.getAccountNum()+" Total Balance :"+temp.getCustomerBalance());
			ftTemp.settDetails("Date :"+tDate+" Depsoited Amount :"+money+" From Acc No: "+temp.getAccountNum()+" Total Balance :"+ftTemp.getCustomerBalance());
			dao.updateDetails(temp.getAccountNum(), temp);
			dao.updateDetails(ftTemp.getAccountNum(), ftTemp);
			return true;
		}
	} else if(temp.getCustomerBalance()<money) {
		System.out.println("Low Balance to transfer");
	} else {
		System.out.println("No such user account");
	}
	return false;
	}


@Override
public void printTransferdetails() {
	// TODO Auto-generated method stub
	ArrayList<String> tempDetails = new ArrayList<String>();
	tempDetails = temp.gettDetails();
	Stream printList = tempDetails.stream();
	printList.forEach(System.out::println);
	
}


@Override
public int generateAccountId() {
	// TODO Auto-generated method stub
	
	int AccountId=(int) (Math.random()*10000);
	return AccountId;
}


	
}



