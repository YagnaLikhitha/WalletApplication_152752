package com.project.wallet.dao;

import java.util.TreeMap;

import com.project.wallet.bean.Account;
import com.project.wallet.exception.WalletException;

public class WalletDao implements IWalletDao {
	
	TreeMap<Integer, Account> tmap = new TreeMap<Integer, Account>();
	@Override
	public int accountCreation(Account account) {
		tmap.put(account.getAccountNum(), account);
		return account.getAccountNum();
	}
	@Override
	public Account loginUser(int accountNumber) throws WalletException {
		Account temp = new Account();
		
		try {
			temp = tmap.get(accountNumber);
			return temp;
				
		}
		catch(NullPointerException e) {
			if(temp==null)
			throw new WalletException("There is no Account");
		}
		return null;
	}
	@Override
	public void updateDetails(int accountNumber, Account account) {
		tmap.replace(accountNumber, account);
		
	}

}
