package com.project.wallet.service;

import com.project.wallet.bean.Account;
import com.project.wallet.exception.WalletException;

public interface IWalletService {

	
	int addAccountDao(Account account);
	double depositDao(double money);
	double withdrawDao(double money) ;
	double showBalanceDao();
	boolean checkLogin(int accountNumber) throws WalletException;
	boolean checkPassword(String password);
	String currentUser();
	boolean transferAmount(int toAccountNumber, double money) throws WalletException;
	void printTransferdetails();
	int generateAccountId();
}
