package com.project.wallet.dao;

import com.project.wallet.bean.Account;
import com.project.wallet.exception.WalletException;

public interface IWalletDao {
	
	int accountCreation(Account account);
	
	Account loginUser(int accountNumber) throws WalletException;
	
	void updateDetails(int accountNumber, Account account);

}
