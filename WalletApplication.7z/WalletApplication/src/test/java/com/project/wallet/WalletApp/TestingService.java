package com.project.wallet.WalletApp;

import static org.junit.Assert.*;

import org.junit.Test;

import com.project.wallet.bean.Account;
import com.project.wallet.dao.WalletDao;
import com.project.wallet.exception.WalletException;
import com.project.wallet.service.WalletService;

import junit.framework.Assert;

public class TestingService {

	@Test
	public void testValidatePhoneNo() {
		WalletService check = new WalletService();
	
	Assert.assertEquals(true, check.validateCustPhoneNumber("9874563210"));
		
	}
	
	@Test
	public void testValidateName() {
		WalletService check = new WalletService();
	
	Assert.assertEquals(true, check.validateCustName("Matt Preston"));
		
	}
	
	@Test
	public void testValidatePwd() {
		WalletService check = new WalletService();
	
	Assert.assertEquals(true, check.validateCustPwd("Preston123@"));
		
	}

	@Test
	public void testValidateAge()
	{
		WalletService check = new WalletService();
		Assert.assertEquals(true, check.validateCustAge(64));
	}
	
	@Test
	public void testValidateAmt()
	{
		WalletService check = new WalletService();
		Assert.assertEquals(true, check.validateAmt(7000.00));
	}
	@Test
	public void testValidatePhoneNoFail() {
		WalletService check = new WalletService();
	
	assertEquals(false, check.validateCustPhoneNumber("111111111111111"));
		
	}
	
	@Test
	public void testValidateNameFail() {
		WalletService check = new WalletService();
	
	Assert.assertEquals(false, check.validateCustName("Matt123"));
		
	}
	
	@Test
	public void testValidatePwdFail() {
		WalletService check = new WalletService();
	
	Assert.assertEquals(false, check.validateCustPwd("@! MAtt.Prr"));
		
	}

	@Test
	public void testValidateAgeFail()
	{
		WalletService check = new WalletService();
		Assert.assertEquals(false, check.validateCustAge(199));
	}
	
	@Test
	public void testValidateAmtFail()
	{
		WalletService check = new WalletService();
		Assert.assertEquals(false, check.validateAmt(0.00));
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testAccCreation()
	{
		WalletDao w = new WalletDao();
		Account a = new Account();
		Assert.assertEquals(10100,w.accountCreation(a));
		Account a1 = new Account();
		Assert.assertEquals(10101,w.accountCreation(a1));
		Account a2 = new Account();
		Assert.assertEquals(10102,w.accountCreation(a2));
		
	}
	
	
	@Test
	public void testDepositAmt()
	{
		WalletService w = new WalletService();
		Account a = new Account();
		Assert.assertEquals(2000.00, w.depositDao(1000.00));
		Assert.assertEquals(4000.00, w.depositDao(1000.00));
		
	}
	
	@Test
	public void testWithdrawAmt() throws Exception
	{
		WalletService w = new WalletService();
		Account a = new Account();
		
		Assert.assertEquals(5000.00, w.depositDao(5000.00));
		Assert.assertEquals(6000.00, w.withdrawDao(6000.00));
		Assert.assertEquals(00.00, w.withdrawDao(1000.00));
		
	}
	
	@Test
	public void testDispBal()
	{
		WalletService w = new WalletService();
		Account a = new Account();
		Assert.assertEquals(0.00,w.showBalanceDao());
		
		
	}
	
	@Test
	public void testLogin() throws WalletException
	{
		WalletDao w = new WalletDao();
		Account a = new Account();
		w.accountCreation(a);
		Account a1 = new Account();
		w.accountCreation(a1);
		Account a2 = new Account();
		w.accountCreation(a2);
		Account a3 = new Account();
		w.accountCreation(a3);
		System.out.println(a3.getAccountNum());
		Assert.assertEquals(a1, w.loginUser(5532));
	}
}
